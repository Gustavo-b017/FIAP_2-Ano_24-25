package br.com.fiap.concessionaria.model;

import java.util.ArrayList;
import java.util.List;

public class CarroDAO {
    private List<Carro> carros = new ArrayList<>();

    public void salvarCarro(Carro carro) {
        carros.add(carro);
    }

    public List<Carro> listarCarros() {
        return carros;
    }
}

