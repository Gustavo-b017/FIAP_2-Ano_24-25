package br.com.fiap.concessionaria.teste;

import br.com.fiap.concessionaria.controller.CarroController;
import br.com.fiap.concessionaria.model.CarroDAO;
import br.com.fiap.concessionaria.view.CarroView;

public class Teste {

	public static void main(String[] args) {
		CarroDAO model = new CarroDAO();
        CarroView view = new CarroView();
        CarroController controller = new CarroController(view, model);
        view.setVisible(true);

	}

}
