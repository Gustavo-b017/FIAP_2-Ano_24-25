package br.com.fiap.estoque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstoqueApplicationTests {

    @Test
    void contextLoads() {
    }

}
