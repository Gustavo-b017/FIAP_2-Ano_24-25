package br.com.fiap.estoque.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "PRODUTO")
@Getter
@Setter
public class Produto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_PRODUTO")
    private Integer id;

    @NotBlank(message = "O campo nome é obrigatório.")
    @Size(max = 100, message = "O campo nome deve ter no máximo 100 caracteres.")
    @Column(name = "NOME" , nullable = false, length = 100)
    private String nome;

    @NotNull(message = "O variável preço deve ser informada.")
    @DecimalMin(value = "0.1", message = "O campo preço deve ser maior que zero.")
    @Column(name = "PRECO", nullable = false, precision = 10, scale = 2)
    private BigDecimal preco;

    @NotNull(message = "A variável quantidade deve ser preenchida.")
    @Column(name = "QUANTIDADE", nullable = false)
    private Integer quantidade;

    @NotNull(message = "A variável dataCriacao deve ser informada.")
    @PastOrPresent(message = "A variável dataCriacao está inválida.")
    @Column(name = "DATA_CRIACAO", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCriacao;

}
