package br.com.fiap.exercicio.um;

public class Retangulo extends FormaGeometrica {

	@Override
	public double calcularPerimetro(double valor1, double valor2) {
		
		double retorno = 2 * valor1 + 2 * valor2;
		return retorno;

	}

	@Override
	public double calcularArea(double valor1, double valor2) {
		
		double retorno = valor1 * valor2;
		
		return retorno;

	}

}
