package br.com.fiap.exercicio.um;

public class Teste {

	public static void main(String[] args) {
		
		Circulo circulo = new Circulo();
		System.out.println("A área do circulo é: " + circulo.calcularArea(3.14, 2));
		System.out.println("A perímetro do circulo é: " + circulo.calcularPerimetro(3.14, 3));
		
		Retangulo retangulo = new Retangulo();
		System.out.println("A área do retangulo é: " + retangulo.calcularArea(4, 2));
		System.out.println("A perímetro do retangulo é: " + retangulo.calcularPerimetro(4, 3));

	}

}
