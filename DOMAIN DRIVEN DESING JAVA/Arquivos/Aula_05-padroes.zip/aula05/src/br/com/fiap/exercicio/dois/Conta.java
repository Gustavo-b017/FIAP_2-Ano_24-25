package br.com.fiap.exercicio.dois;

public class Conta {
	
	private double saldo;
	
	private Banco banco;
	
	public void exibirSaldo() {
		System.out.println("O saldo da conta é: " + saldo);
		banco.exibirDadosBancarios();
	}

	public double getSaldo() {
		return saldo;
	}

	public Banco getBanco() {
		return banco;
	}

	public void setBanco(Banco banco) {
		this.banco = banco;
	}

}
