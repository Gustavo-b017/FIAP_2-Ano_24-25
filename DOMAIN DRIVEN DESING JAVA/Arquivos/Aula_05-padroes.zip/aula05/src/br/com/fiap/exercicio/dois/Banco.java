package br.com.fiap.exercicio.dois;

public final class Banco {
	
	private String nome;
	
	private String agencia;
	
	public void exibirDadosBancarios() {
		System.out.println("");
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

}
