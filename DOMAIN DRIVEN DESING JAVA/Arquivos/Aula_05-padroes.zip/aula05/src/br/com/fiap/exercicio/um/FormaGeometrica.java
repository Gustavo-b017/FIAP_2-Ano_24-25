package br.com.fiap.exercicio.um;

public abstract class FormaGeometrica {
	
	public abstract double calcularPerimetro(double valor1, double valor2);
	
	public abstract double calcularArea(double valor1, double valor2);
	

}
