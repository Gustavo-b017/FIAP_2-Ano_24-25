package br.com.fiap.estoque.controllers;

import br.com.fiap.estoque.entities.Produto;
import br.com.fiap.estoque.services.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/produtos")
public class ProdutoController {

    @Autowired
    private ProdutoService produtoService;

    @PostMapping
    public void salvarProduto(@RequestBody Produto produto) {
        produtoService.criarProduto(produto);
    }

    @GetMapping
    public List<Produto> buscarTodosProdutos() {
        return produtoService.buscarProdutos();
    }
}
