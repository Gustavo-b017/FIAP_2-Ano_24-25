package br.com.fiap.estoque.services;

import br.com.fiap.estoque.entities.Produto;
import br.com.fiap.estoque.repositories.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository produtoRepository;

    public void criarProduto(Produto produto) {
        produtoRepository.save(produto);
    }

    public Produto buscarProdutoPorNome(String nome) {
        return produtoRepository.findByNome(nome);
    }

    public void apagarProduto(Produto produto) {
        produtoRepository.deleteById(produto.getId());
    }

    public List<Produto> buscarProdutos() {
        return produtoRepository.findAll();
    }

}
