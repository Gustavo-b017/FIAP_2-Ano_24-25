package br.com.fiap.rh.teste;

import java.util.LinkedList;
import java.util.Queue;

public class TesteFila {

	public static void main(String[] args) {
		
		Queue<Integer> lista = new LinkedList<Integer>();
		lista.add(1);
		lista.add(2);
		lista.add(1);
		lista.add(4);
		lista.add(3);
		System.out.println("O head da lista é :" + lista.remove());
		for(Integer numero: lista) {
			System.out.println(numero);
		}
		

	}

}
