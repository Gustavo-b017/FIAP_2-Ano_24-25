package br.com.fiap.rh.teste;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class TesteSet {

	public static void main(String[] args) {
		
		/*Set<Integer> lista = new HashSet<>();
		lista.add(1);
		lista.add(2);
		lista.add(1);
		lista.add(4);
		lista.add(3);
		
		for(Integer numero : lista) {
			System.out.println( numero);
		}*/
		
		
		Set<Integer> lista1 = new LinkedHashSet<>();
		lista1.add(4);
		lista1.add(2);
		lista1.add(1);
		lista1.add(4);
		lista1.add(3);
		
		for(Integer numero : lista1) {
			System.out.println( numero);
		}

	}

}
