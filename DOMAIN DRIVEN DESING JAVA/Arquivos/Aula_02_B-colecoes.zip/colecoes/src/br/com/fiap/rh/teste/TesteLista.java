package br.com.fiap.rh.teste;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import br.com.fiap.rh.model.Endereco;
import br.com.fiap.rh.model.Pessoa;

public class TesteLista {

	public static void main(String[] args) {
		
		/*List<String> lista = new ArrayList<>();
		lista.add("Teste 1");
		lista.add("Teste 2");
		
		for(String texto : lista) {
			System.out.println(texto);
		}
		
		Pessoa pessoa1 = new Pessoa("Evando", "111111", 55);
		Pessoa pessoa2 = new Pessoa("Teste", "1234", 55);
		
		List<Pessoa> pessoas = new ArrayList<>();
		pessoas.add(pessoa1);
		pessoas.add(pessoa2);
		
		for(Pessoa pessoa : pessoas) {
			pessoa.imprimir();
		}

		for(int i = 0; i < 5; i++) {
			Pessoa pessoa = new Pessoa("Teste" + i, i+i+""+i+i+i, i);
			pessoa.imprimir();
			pessoas.add(pessoa);
		}*/
		
		// CRIACAO DA PESSOA 1
		
		/*List<Pessoa> pessoas = new ArrayList<>();
		List<Endereco> enderecosPessoa1 = new ArrayList<Endereco>();
		
		Pessoa pessoa1 = new Pessoa("Pessoa1", "111111", 55);
		
		Endereco residencial = new Endereco("Av Paulista", 1000, "08432334");
		Endereco comercial = new Endereco("Rua Moema", 10, "08342343");
		
		enderecosPessoa1.add(residencial);
		enderecosPessoa1.add(comercial);
		
		pessoa1.setEnderecos(enderecosPessoa1);
		
		pessoas.add(pessoa1);
		
		// CRIACAO DA PESSOA 2
		
		Endereco residencial2 = new Endereco("Av Interlagos", 500, "08432334");
		Endereco comercial2 = new Endereco("Rua Alameda Santos", 10, "08342343");
		
		List<Endereco> enderecosPessoa2 = new ArrayList<Endereco>();
		
		enderecosPessoa2.add(comercial2);
		enderecosPessoa2.add(residencial2);
		
		
		Pessoa pessoa2 = new Pessoa("Pessoa2", "1234", 55, enderecosPessoa2);
		
		pessoas.add(pessoa2);
		
		for(Pessoa pessoa : pessoas) {
			pessoa.imprimir();
		}*/
		
		List<Integer> lista1 = new ArrayList<Integer>();
		lista1.add(1);
		lista1.add(2);
		lista1.add(3);
		lista1.add(4);
		
		System.out.println("O elemento 2 da lista é " + lista1.get(1));
		
		
		List<Integer> lista2 = new LinkedList<Integer>();
		lista2.add(2);
		lista2.add(1);
		lista2.add(3);
		lista2.add(4);
		
		for(Integer numero : lista2) {
			System.out.println(numero);
		}
		
		
	}
}
