package integracaoBancoDeDados;

import java.sql.SQLException;

public class Teste {
	
	public static void main(String[] args) throws SQLException {
		
		Aluno aluno = new Aluno();
		
		aluno.incluirAluno();
		
		aluno.consultarAluno();
		
	}

}
