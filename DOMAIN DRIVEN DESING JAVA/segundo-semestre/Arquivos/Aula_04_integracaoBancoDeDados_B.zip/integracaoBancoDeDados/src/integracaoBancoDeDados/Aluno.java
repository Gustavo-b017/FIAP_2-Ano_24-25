package integracaoBancoDeDados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Aluno {
	
	private String url = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL";
	private String user = "pf2012";
	private String password = "";
	
	private String insert = "INSERT INTO ALUNO(ID, NOME, DOCUMENTO) VALUES (?,?,?)";
	String select = "SELECT * FROM ALUNO";
	String delete = "DELETE FROM ALUNO WHERE ID = ?";
	
	String update = "UPDATE ALUNO SET NOME = ?,  DOCUMENTO = ? WHERE ID = ?";
	
	public void incluirAluno() throws SQLException{
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		
		try {
			
			conn = DriverManager.getConnection(url, user, password);
			preparedStatement = conn.prepareStatement(insert);
			
			preparedStatement.setInt(1, 2);
			preparedStatement.setString(2, "Teste");
			preparedStatement.setString(3, "12341234123");
			preparedStatement.executeUpdate();
			System.out.println("Inclusão efetuada com sucesso.");
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			preparedStatement.close();
			conn.close();
		}
	}
	
	public void consultarAluno() throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		
		try {
			
			conn = DriverManager.getConnection(url, user, password);
			preparedStatement = conn.prepareStatement(insert);
			
			preparedStatement =  conn.prepareStatement(select);
			ResultSet result = preparedStatement.executeQuery();
			while(result.next()) {
				int id = result.getInt("ID");
				String nome = result.getString("NOME");
				String documento = result.getString("DOCUMENTO");
				System.out.println(" ID: " + id + " NOME: " + nome + " DOCUMENTO: " + documento);
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			preparedStatement.close();
			conn.close();
		}
	}
	
	public void apagarAluno() throws SQLException{
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		
		try {
			
			conn = DriverManager.getConnection(url, user, password);
			preparedStatement = conn.prepareStatement(delete);
			
			preparedStatement.setInt(1, 2);
			preparedStatement.executeUpdate();
			System.out.println("Inclusão efetuada com sucesso.");
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			preparedStatement.close();
			conn.close();
		}
	}

}
