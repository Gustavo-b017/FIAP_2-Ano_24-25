package br.com.fiap.estoque.controllers;

import br.com.fiap.estoque.entities.Usuario;
import br.com.fiap.estoque.security.JwtUtil;
import br.com.fiap.estoque.services.UsuarioService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/auth")
public class AuthController {

    private final UsuarioService usuarioService;

    public AuthController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password) {

        Usuario usuario = usuarioService.buscarPorUsername(username);
        if (usuario != null && usuario.getPassword().equals(password)) {
            return JwtUtil.gerarToken(usuario.getUsername(), usuario.getRole());
        } else {
            return "Credenciais inválidas!";
        }
    }
}

