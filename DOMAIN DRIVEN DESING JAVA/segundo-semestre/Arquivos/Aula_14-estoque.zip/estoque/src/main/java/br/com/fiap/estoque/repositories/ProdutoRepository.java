package br.com.fiap.estoque.repositories;

import br.com.fiap.estoque.entities.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProdutoRepository extends JpaRepository<Produto, Integer> {

    // SELECT * FROM PRODUTO WHERE NOME = ?

    //@Query(value = "Query complexa")
    public List<Produto> findByNome(String nome);
}
