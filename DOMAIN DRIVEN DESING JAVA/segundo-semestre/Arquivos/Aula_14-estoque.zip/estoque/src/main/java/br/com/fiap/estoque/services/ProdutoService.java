package br.com.fiap.estoque.services;

import br.com.fiap.estoque.entities.Produto;
import br.com.fiap.estoque.repositories.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository produtoRepository;

    public void criarProduto(Produto produto) {
        produtoRepository.save(produto);
    }

    public List<Produto> burcarProdutoPorNome(String nome) {
        return produtoRepository.findByNome(nome);
    }

    public List<Produto> buscarTodosProdutos() {
        return produtoRepository.findAll();
    }
}
