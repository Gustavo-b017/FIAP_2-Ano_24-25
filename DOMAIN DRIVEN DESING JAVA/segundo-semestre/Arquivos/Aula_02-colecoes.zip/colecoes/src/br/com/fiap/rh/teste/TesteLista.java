package br.com.fiap.rh.teste;

import java.util.ArrayList;
import java.util.List;

import br.com.fiap.rh.model.Pessoa;

public class TesteLista {

	public static void main(String[] args) {
		
		List<String> lista = new ArrayList<>();
		lista.add("Teste 1");
		lista.add("Teste 2");
		
		for(String texto : lista) {
			System.out.println(texto);
		}
		
		Pessoa pessoa1 = new Pessoa("Evando", "111111", 55);
		Pessoa pessoa2 = new Pessoa("Teste", "1234", 55);
		
		List<Pessoa> pessoas = new ArrayList<>();
		pessoas.add(pessoa1);
		pessoas.add(pessoa2);
		
		for(Pessoa pessoa : pessoas) {
			pessoa.imprimir();
		}

		for(int i = 0; i < 5; i++) {
			Pessoa pessoa = new Pessoa("Teste" + i, i+i+""+i+i+i, i);
			pessoa.imprimir();
			pessoas.add(pessoa);
		}
			
			
			
			
			
			
			
			
			
	}
}
