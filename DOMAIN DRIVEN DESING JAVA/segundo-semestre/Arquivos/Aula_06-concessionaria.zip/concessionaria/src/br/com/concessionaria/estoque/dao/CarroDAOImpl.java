package br.com.concessionaria.estoque.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import br.com.concessionaria.estoque.entities.Carro;

public class CarroDAOImpl implements CarroDAO {
	
	private Connection conn;
	
	public CarroDAOImpl(Connection conn) {
		this.conn = conn;
	}

	@Override
	public void salvar(Carro carro) {
		
		String insert = "INSERT INTO CARRO (ID, MARCA, MODELO, PRECO, ANO) VALUES(?, ?, ?, ?, ?)";
		
		try (PreparedStatement preparedStatement = conn.prepareStatement(insert)) {
			
			preparedStatement.setInt(1, carro.getId());
			preparedStatement.setString(2, carro.getMarca());
			preparedStatement.setString(3, carro.getModelo());
			preparedStatement.setDouble(4, carro.getPreco());
			preparedStatement.setInt(5, carro.getAno());
			preparedStatement.executeUpdate();
			System.out.println("Inclusão efetuada com sucesso.");
			
		} catch (SQLException e) {
			e.printStackTrace();
		} 

	}

	@Override
	public void atualizar(Carro carro) {
		
		String update = "UPDATE CARRO SET MARCA=?, MODELO=?, PRECO=?, ANO=? WHERE ID=?";
		
		try (PreparedStatement preparedStatement = conn.prepareStatement(update)) {
			
			preparedStatement.setString(1, carro.getMarca());
			preparedStatement.setString(2, carro.getModelo());
			preparedStatement.setDouble(3, carro.getPreco());
			preparedStatement.setInt(4, carro.getAno());
			preparedStatement.setInt(5, carro.getId());
			
			preparedStatement.executeUpdate();
			System.out.println("Atualização efetuada com sucesso.");
			
		} catch (SQLException e) {
			e.printStackTrace();
		} 

	}

	@Override
	public Carro buscarPorId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void apagar(int id) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Carro> listarTodos() {
		// TODO Auto-generated method stub
		return null;
	}

}
