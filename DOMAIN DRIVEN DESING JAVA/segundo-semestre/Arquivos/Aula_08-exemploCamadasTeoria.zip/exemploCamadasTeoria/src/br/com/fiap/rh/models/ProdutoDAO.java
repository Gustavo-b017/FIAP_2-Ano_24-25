package br.com.fiap.rh.models;

import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO {
    private List<Produto> produtos = new ArrayList<>(); // Simulação de banco

    public void salvarProduto(Produto produto) {
        produtos.add(produto);
        System.out.println("Produto salvo: " + produto.getNome());
    }

    public List<Produto> listarProdutos() {
        return produtos;
    }
}

