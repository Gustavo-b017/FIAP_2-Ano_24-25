package br.com.fiap.rh.controllers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import br.com.fiap.rh.models.Produto;
import br.com.fiap.rh.services.ProdutoService;
import br.com.fiap.rh.views.ProdutoView;

public class ProdutoController {
    private ProdutoView view;
    private ProdutoService service;

    public ProdutoController(ProdutoView view, ProdutoService service) {
        this.view = view;
        this.service = service;

        // Vincula os botões aos eventos
        this.view.addSalvarListener(new SalvarProdutoListener());
        this.view.addListarListener(new ListarProdutosListener());
    }

    class SalvarProdutoListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                String nome = view.getNome();
                double preco = view.getPreco();

                service.salvarProduto(nome, preco);
                view.displayProdutos("Produto salvo com sucesso!");
            } catch (Exception ex) {
                view.displayErrorMessage("Erro ao salvar produto: " + ex.getMessage());
            }
        }
    }

    class ListarProdutosListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            StringBuilder lista = new StringBuilder();
            for (Produto produto : service.listarProdutos()) {
                lista.append(produto.getNome())
                     .append(" - R$ ")
                     .append(produto.getPreco())
                     .append("\n");
            }
            view.displayProdutos(lista.toString());
        }
    }
}

