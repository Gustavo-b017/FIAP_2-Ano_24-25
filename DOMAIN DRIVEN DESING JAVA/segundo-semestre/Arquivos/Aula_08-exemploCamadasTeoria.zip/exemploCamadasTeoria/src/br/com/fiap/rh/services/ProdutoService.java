package br.com.fiap.rh.services;

import java.util.List;

import br.com.fiap.rh.models.Produto;
import br.com.fiap.rh.models.ProdutoDAO;

public class ProdutoService {
	
    private ProdutoDAO dao = new ProdutoDAO(); // Interação com a persistência

    // Valida e processa o cadastro de um produto
    public void salvarProduto(String nome, double preco) throws Exception {
        if (nome == null || nome.isEmpty()) {
            throw new Exception("O nome do produto não pode ser vazio!");
        }
        if (preco <= 0) {
            throw new Exception("O preço do produto deve ser maior que zero!");
        }

        // Salva no DAO
        dao.salvarProduto(new Produto(nome, preco));
    }

    // Retorna a lista de produtos
    public List<Produto> listarProdutos() {
        return dao.listarProdutos();
    }
}

