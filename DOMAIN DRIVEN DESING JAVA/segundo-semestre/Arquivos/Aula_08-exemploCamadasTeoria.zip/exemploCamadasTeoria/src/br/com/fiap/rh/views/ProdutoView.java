package br.com.fiap.rh.views;

import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ProdutoView extends JFrame {
    private JTextField nomeField = new JTextField(20); // Campo para o nome do produto
    private JTextField precoField = new JTextField(10); // Campo para o preço do produto
    private JButton salvarButton = new JButton("Salvar Produto"); // Botão para salvar
    private JButton listarButton = new JButton("Listar Produtos"); // Botão para listar
    private JTextArea displayArea = new JTextArea(10, 30); // Área para exibir produtos

    public ProdutoView() {
        JPanel panel = new JPanel();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(400, 300);

        panel.add(new JLabel("Nome:"));
        panel.add(nomeField);
        panel.add(new JLabel("Preço:"));
        panel.add(precoField);
        panel.add(salvarButton);
        panel.add(listarButton);
        panel.add(new JScrollPane(displayArea)); // Área para exibir dados

        this.add(panel);
    }

    // Métodos para capturar dados inseridos pelo usuário
    public String getNome() {
        return nomeField.getText();
    }

    public double getPreco() {
        try {
            return Double.parseDouble(precoField.getText());
        } catch (NumberFormatException e) {
            return 0; // Retorna 0 se o preço for inválido
        }
    }

    // Métodos para adicionar eventos aos botões
    public void addSalvarListener(ActionListener salvarListener) {
        salvarButton.addActionListener(salvarListener);
    }

    public void addListarListener(ActionListener listarListener) {
        listarButton.addActionListener(listarListener);
    }

    // Exibe os produtos na área de texto
    public void displayProdutos(String produtos) {
        displayArea.setText(produtos);
    }

    public void displayErrorMessage(String mensagemErro) {
        JOptionPane.showMessageDialog(this, mensagemErro);
    }
}

