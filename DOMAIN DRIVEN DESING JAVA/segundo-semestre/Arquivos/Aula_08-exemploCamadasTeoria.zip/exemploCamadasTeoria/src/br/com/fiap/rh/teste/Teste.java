package br.com.fiap.rh.teste;

import br.com.fiap.rh.controllers.ProdutoController;
import br.com.fiap.rh.services.ProdutoService;
import br.com.fiap.rh.views.ProdutoView;

public class Teste {
	
	public static void main(String[] args) {
		
        ProdutoView view = new ProdutoView();
        ProdutoService service = new ProdutoService();
        ProdutoController controller = new ProdutoController(view, service);

        // Exibe a interface gráfica
        view.setVisible(true);
    }

}
