package br.com.fiap.exemplo.estatico;

public class Teste {

	public static void main(String[] args) {
		
		//Compra compra = null;
		
		//compra.efetivarCompra();
		
		System.out.println(Compra.titulo + " " + Compra.fixarFrete());

	}

}
