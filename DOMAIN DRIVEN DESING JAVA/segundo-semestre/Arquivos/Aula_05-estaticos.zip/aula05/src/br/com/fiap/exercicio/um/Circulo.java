package br.com.fiap.exercicio.um;

public class Circulo extends FormaGeometrica {

	@Override
	public double calcularPerimetro(double valor1, double valor2) {
		
		//2 PI r
		double retorno = 2 * valor1 * valor2;
		return retorno;

	}

	@Override
	public double calcularArea(double valor1, double valor2) {
		// PI rˆ2
		double retorno = valor1 * (valor2 * valor2);
		
		return retorno;

	}
	
	public void testar() {
		
	}

}
