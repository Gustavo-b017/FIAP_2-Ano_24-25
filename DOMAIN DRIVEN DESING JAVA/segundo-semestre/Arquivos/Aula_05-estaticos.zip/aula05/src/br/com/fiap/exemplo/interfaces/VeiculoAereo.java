package br.com.fiap.exemplo.interfaces;

public interface VeiculoAereo {
	
	void voar();

}
