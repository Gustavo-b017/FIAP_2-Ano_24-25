package br.com.fiap.exemplo.interfaces;

public interface Veiculo extends VeiculoAereo{
	
	void acelerar();
	
	void frear();
	
	default void ligarMotor() {
		System.out.println("Motor ligado.");
	}

}
