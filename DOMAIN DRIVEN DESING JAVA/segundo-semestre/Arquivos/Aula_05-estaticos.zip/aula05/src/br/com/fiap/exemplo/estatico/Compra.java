package br.com.fiap.exemplo.estatico;

public class Compra {
	
	private int numCompra;
	
	private double valorCompra;
	
	public final static String titulo = "Compra Online";
	
	public Compra(int numCompra, double valorCompra) {
		this.numCompra = numCompra;
		this.valorCompra = valorCompra;
	}

	public void efetivarCompra() {
		System.out.println("A compra " + this.numCompra + " do valor " + this.valorCompra + " efetuada com sucesso.");
	}
	
	public static double fixarFrete() {
		return 10.0;
	}

	public int getNumCompra() {
		return numCompra;
	}

	public void setNumCompra(int numCompra) {
		this.numCompra = numCompra;
	}

	public double getValorCompra() {
		return valorCompra;
	}

	public void setValorCompra(double valorCompra) {
		this.valorCompra = valorCompra;
	}

}
