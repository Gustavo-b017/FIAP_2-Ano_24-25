package br.com.fiap.delivery.model;

import java.util.List;

public class Pedido {
	
	private int numeroPedido;
	
	private int qtdeProduto;
	
	private List<Produto> produtos;
	
	public Pedido(int numeroPedido, int qtdeProduto, List<Produto> produtos) {
		this.numeroPedido = numeroPedido;
		this.qtdeProduto = qtdeProduto;
		this.produtos = produtos;
	}

	public int getNumeroPedido() {
		return numeroPedido;
	}

	public void setNumeroPedido(int numeroPedido) {
		this.numeroPedido = numeroPedido;
	}

	public int getQtdeProduto() {
		return qtdeProduto;
	}

	public void setQtdeProduto(int qtdeProduto) {
		this.qtdeProduto = qtdeProduto;
	}

	public List<Produto> getProdutos() {
		return produtos;
	}

	public void setProdutos(List<Produto> produtos) {
		this.produtos = produtos;
	}
	
	public void adicionarProdutoAoCarrinho(Produto produto) {
		
		try {
			
			produtos.add(produto);
			
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
		} finally {
			System.out.println("Passou aqui!!!");
		}
		
	}

}
