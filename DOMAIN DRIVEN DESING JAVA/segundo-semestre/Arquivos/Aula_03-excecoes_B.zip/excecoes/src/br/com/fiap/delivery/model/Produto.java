package br.com.fiap.delivery.model;

public class Produto {
	
	private String nome;
	
	private float valor;
	
	private String descricao;
	
	private float tamanho;
	
	

	public Produto(String nome, float valor, String descricao, float tamanho) {
		this.nome = nome;
		this.valor = valor;
		this.descricao = descricao;
		this.tamanho = tamanho;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public float getTamanho() {
		return tamanho;
	}

	public void setTamanho(float tamanho) {
		this.tamanho = tamanho;
	}
	
	public void verificarPreco() {
		System.out.println("O valor do produto é: " + this.valor);
	}
}
