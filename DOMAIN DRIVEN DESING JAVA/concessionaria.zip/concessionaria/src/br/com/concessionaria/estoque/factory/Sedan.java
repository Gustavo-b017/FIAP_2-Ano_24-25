package br.com.concessionaria.estoque.factory;

public class Sedan implements TipoCarro {

	@Override
	public void exibirTipoCarro() {
		System.out.println("O tipo do carro é Sedan.");
	}

}
