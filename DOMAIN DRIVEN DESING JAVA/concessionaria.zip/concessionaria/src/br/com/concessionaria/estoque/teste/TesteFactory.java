package br.com.concessionaria.estoque.teste;

import br.com.concessionaria.estoque.factory.TipoCarro;
import br.com.concessionaria.estoque.factory.TipoCarroFactory;

public class TesteFactory {

	public static void main(String[] args) {
		
		TipoCarro tipoCarro = TipoCarroFactory.criarTipoCarro("sedan");
		tipoCarro.exibirTipoCarro();
	}

}
