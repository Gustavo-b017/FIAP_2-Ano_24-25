package br.com.concessionaria.estoque.factory;

public interface TipoCarro {
	
	void exibirTipoCarro();

}
