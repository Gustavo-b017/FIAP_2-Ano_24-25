package br.com.concessionaria.estoque.factory;

public class SUV implements TipoCarro {

	@Override
	public void exibirTipoCarro() {
		System.out.println("O tipo carro é SUV.");

	}

}
