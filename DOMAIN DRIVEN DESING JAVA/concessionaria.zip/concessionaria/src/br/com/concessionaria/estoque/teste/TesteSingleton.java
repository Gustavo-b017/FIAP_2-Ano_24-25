package br.com.concessionaria.estoque.teste;

import br.com.concessionaria.estoque.dao.CarroDAO;
import br.com.concessionaria.estoque.dao.CarroDAOImpl;
import br.com.concessionaria.estoque.entities.Carro;
import br.com.concessionaria.estoque.util.ConexaoDB;

public class TesteSingleton {
	
	public static void main(String[] args) {
		
		CarroDAO carroDAO = new CarroDAOImpl(ConexaoDB.getInstance().getConnection());
		
		Carro carro = new Carro();
		
		
		carroDAO.salvar(null);
		
	}

}
