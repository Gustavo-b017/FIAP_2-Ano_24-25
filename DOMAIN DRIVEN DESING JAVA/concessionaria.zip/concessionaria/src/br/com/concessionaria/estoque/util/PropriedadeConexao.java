package br.com.concessionaria.estoque.util;

import java.util.Properties;

public class PropriedadeConexao {
	
	public static Properties retornarPropriedades() {
		Properties prop = new Properties();
		prop.put("user", "pf2012");
		prop.put("password", "");
		return prop;
	}

}
