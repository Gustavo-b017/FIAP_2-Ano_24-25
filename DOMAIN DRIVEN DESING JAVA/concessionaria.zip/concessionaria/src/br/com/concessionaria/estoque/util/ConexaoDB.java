package br.com.concessionaria.estoque.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoDB {
	
	private static ConexaoDB instancia;
	private Connection conn;
	
	private ConexaoDB() {
		String url = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL";
		
		try {
			conn = DriverManager.getConnection(url, PropriedadeConexao.retornarPropriedades());
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static ConexaoDB getInstance() {
		if(instancia == null) {
			instancia = new ConexaoDB();
		}
		return instancia;
	}
	
	public Connection getConnection() {
		return conn;
	}

}
