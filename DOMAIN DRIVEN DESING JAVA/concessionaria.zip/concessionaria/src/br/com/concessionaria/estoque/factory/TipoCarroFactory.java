package br.com.concessionaria.estoque.factory;

public class TipoCarroFactory {
	
	public static TipoCarro criarTipoCarro(String tipoCarro) {
		
		if("sedan".equals(tipoCarro)) {
			return new Sedan();
		} else if ("SUV".equals(tipoCarro) ) {
			return new SUV();
		}
		return null;
	}
}
