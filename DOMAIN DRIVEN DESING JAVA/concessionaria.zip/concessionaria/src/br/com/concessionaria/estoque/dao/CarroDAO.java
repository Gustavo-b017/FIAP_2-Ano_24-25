package br.com.concessionaria.estoque.dao;

import java.util.List;

import br.com.concessionaria.estoque.entities.Carro;

public interface CarroDAO {
	
	void salvar(Carro carro);
	
	void atualizar(Carro carro);
	
	Carro buscarPorId(int id);
	
	void apagar(int id);
	
	List<Carro> listarTodos();

}
