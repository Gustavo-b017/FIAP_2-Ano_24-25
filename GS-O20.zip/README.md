## Grupo BlueVison:

- Gilson Dias - RM552345 
- Gustavo Bezerra - RM553076 


# Para rodar:

1. clone o repositorio localmente
2. utilize o comando 'npm i'
3. depois de intalar as dependencias, escreva 'nmp run dev'
4. click no link que gerar, e pronto 