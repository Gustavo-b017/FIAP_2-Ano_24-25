
export const footerIcons = [
  {
    id: 1,
    nome: "logo-instagram"
  },
  {
    id: 2,
    nome: "logo-linkedin"
  },
  {
    id: 3,
    nome: "logo-github"
  }
]