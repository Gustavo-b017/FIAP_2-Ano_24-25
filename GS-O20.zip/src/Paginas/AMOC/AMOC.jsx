import contrucao from './contrucaoPagina.jpg'
function AMOC() {
    return (  
        <div className='AMOC'>

            <img src={contrucao} alt="" />

            <div className="mensagem">
                <h2>Pagina em contrução</h2>
                <p>Estamos trabalhando ativamente para trazer o melhor conteúdo para você.</p>
            </div>
        </div>
    );
}

export default AMOC;