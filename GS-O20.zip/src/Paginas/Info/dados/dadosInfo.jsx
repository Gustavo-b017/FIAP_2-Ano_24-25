import img1 from './oceanos/1.png'
import img2 from './oceanos/2.png'
import img3 from './oceanos/gif.gif'
import img4 from './oceanos/4.png'
import img5 from './oceanos/5.png'
import img6 from './oceanos/6.png'

export const dadosInfo = [
    {
        id: 1,
        icon: img1,
        title: 'First slide labe',
        text: 'Some representative placeholder content for the first slide.'
    },
    {
        id: 2,
        icon: img2,
        title: 'Second slide label',
        text: 'Some representative placeholder content for the first slide.'
    },
    {
        id: 3,
        icon: img3,
        title: 'Second slide label',
        text: 'Some representative placeholder content for the first slide.'
    },
    {
        id: 4,
        icon: img4,
        title: 'Second slide label',
        text: 'Some representative placeholder content for the first slide.'
    },
    {
        id: 5,
        icon: img5,
        title: 'Second slide label',
        text: 'Some representative placeholder content for the first slide.'
    },
    {
        id: 6,
        icon: img6,
        title: 'Third slide label',
        text: 'Some representative placeholder content for the first slide.'
    }
]