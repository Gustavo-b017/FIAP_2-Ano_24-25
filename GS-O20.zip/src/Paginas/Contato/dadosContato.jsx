export const dadosContato = [
    {
        id: 1,
        icon: 'person-circle-outline',
        placeHolder: 'Escreva seu nome...',
    },
    {
        id: 2,
        icon: 'at-outline',
        placeHolder: 'Escreva seu email...',
    },
    {
        id: 3,
        icon: 'mail-outline',
        placeHolder: 'Escreva sua mensagem...',
    }
]