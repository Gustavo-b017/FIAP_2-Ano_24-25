package br.com.fiap.model;

public class ContaPoupanca extends Conta {

	private double rendimento;

	public ContaPoupanca(int agencia, int conta, double rendimento) {		
		this.agencia = agencia;
		this.conta = conta; 
		this.rendimento = rendimento;
	}
	
	public double getRendimento() {
		return rendimento;
	}

	public void setRendimento(double rendimento) {
		this.rendimento = rendimento;
	}

	@Override
	public void sacar(double valor) {
		System.out.println("Foi sacado: " + valor + " reais");
		this.saldo -= valor;
	}

	@Override
	public void depositar(double valor) {
		System.out.println("Foi adicionado: " + valor + " reais");
		this.saldo += valor;
	}

	@Override
	public void exibirSaldo() {
		System.out.println("Vc tem na poupança: " + this.saldo + " Reais");
	}
	
	
}
