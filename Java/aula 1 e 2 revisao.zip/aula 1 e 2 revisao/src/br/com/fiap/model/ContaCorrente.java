package br.com.fiap.model;


public class ContaCorrente extends Conta {
	private double limite;
	
	

	public ContaCorrente(int agencia, int conta, double limite) {		
		this.agencia = agencia;
		this.conta = conta; 
		this.limite = limite;
	}

	public double getLimite() {
		return limite;
	}

	public void setLimite(double limite) {
		this.limite = limite;
	} 
	
	@Override
	public void sacar(double valor) {
		System.out.println("Foi sacado : " + valor + " reais");
		this.saldo -= valor;
	}

	@Override
	public void depositar(double valor) {
		System.out.println("Foi depositado: " + valor + " reais");
		this.saldo += valor;
	}

	@Override
	public void exibirSaldo() {
		System.out.println("Vc tem na conta corrente: " + this.saldo + " Reais");
	}
	
}
