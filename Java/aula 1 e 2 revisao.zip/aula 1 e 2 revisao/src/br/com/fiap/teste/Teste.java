package br.com.fiap.teste;

import br.com.fiap.model.ContaCorrente;
import br.com.fiap.model.ContaPoupanca;

public class Teste {

	public static void main(String[] args) {
		
		ContaCorrente contaCorrente = new ContaCorrente(112, 223, 1000);
		contaCorrente.depositar(200);
		contaCorrente.exibirSaldo();
		contaCorrente.sacar(30);
		contaCorrente.exibirSaldo();
		
		ContaPoupanca contaPoucanca = new ContaPoupanca(001, 222, 3320);
		contaPoucanca.depositar(150);
		contaPoucanca.exibirSaldo();
		contaPoucanca.sacar(30);
		contaPoucanca.exibirSaldo();
		
	}

}
