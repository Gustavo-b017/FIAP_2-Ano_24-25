package integracaoBancoDeDados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Teste {
	
	public static void main(String[] args) throws SQLException {
		
		String url = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL";
		String user = "pf2012";
		String password = "";
		String insert = "INSERT INTO ALUNO(ID, NOME, DOCUMENTO) VALUES (?,?,?)";
		
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		
		try {
			
			conn = DriverManager.getConnection(url, user, password);
			preparedStatement = conn.prepareStatement(insert);
			
			preparedStatement.setInt(1, 2);
			preparedStatement.setString(2, "Teste");
			preparedStatement.setString(3, "12341234123");
			preparedStatement.executeUpdate();
			
			System.out.println("Inclusão efetuada com sucesso.");
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			preparedStatement.close();
			conn.close();
		}
		
	}

}
