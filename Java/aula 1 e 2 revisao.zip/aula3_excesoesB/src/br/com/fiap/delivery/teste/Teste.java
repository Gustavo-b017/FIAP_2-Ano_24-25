package br.com.fiap.delivery.teste;

import java.util.ArrayList;

import br.com.fiap.delivery.model.Pedido;
import br.com.fiap.delivery.model.Produto;

public class Teste {

	public static void main(String[] args) {
		
		
		Pedido pedido = new Pedido(123, 1, new ArrayList<Produto>());
		
		Produto produto = new Produto("mochila", 100.00f, "Mochila de couro", 20.0f);
		
		pedido.adicionarProdutoAoCarrinho(produto);

	}

}
