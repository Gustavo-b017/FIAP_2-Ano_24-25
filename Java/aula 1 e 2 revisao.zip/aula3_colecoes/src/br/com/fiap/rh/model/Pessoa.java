package br.com.fiap.rh.model;

import java.util.List;

public class Pessoa {
	private String nome;
	private String cpf;
	private int idade;
	
	private List<Endereco> enderecos;

	public Pessoa(String nome, int idade, String cpf) {
		this.nome = nome;
		this.cpf = cpf;
		this.idade = idade;
	}
	
	public void imprimir() {
		System.out.println("nome: " + this.nome + ", idade: " + this.idade + ", cpf: " + this.cpf);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}
	public List<Endereco> getEnderecos() {
		return enderecos;
	}

	public void setEnderecos(List<Endereco> enderecos) {
		this.enderecos = enderecos;
	}
	
}
