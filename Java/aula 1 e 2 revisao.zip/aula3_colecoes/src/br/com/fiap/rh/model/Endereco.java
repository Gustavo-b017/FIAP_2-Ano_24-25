package br.com.fiap.rh.model;

public class Endereco {
	private String rua;
	private int numero;
	private String cep;
	
	public Endereco(String rua, int numero, String cep) {
		super();
		this.rua = rua;
		this.numero = numero;
		this.cep = cep;
	}
	
	
}
