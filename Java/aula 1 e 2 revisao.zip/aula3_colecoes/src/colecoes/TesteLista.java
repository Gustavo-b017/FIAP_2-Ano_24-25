package colecoes;

import java.util.ArrayList;
import java.util.List;

import br.com.fiap.rh.model.Pessoa;

public class TesteLista {
	
	public static void main(String[] args) {
		List<String> lista = new ArrayList<>();
		lista.add("Coisa 1");
		lista.add("Coisa 2");
		// lista.add(1); erro por causa q só aceita string
		
		for(String texto : lista) {
			System.out.println(texto);
		}
		
		Pessoa pessoa1 = new Pessoa("Little baby", 555, "01011");
		Pessoa pessoa2 = new Pessoa("big baby", 666, "90192");
	
		List<Pessoa> pessoas = new ArrayList<Pessoa>();
		pessoas.add(pessoa1);
		pessoas.add(pessoa2);
		
		for (Pessoa individuo : pessoas) {
			individuo.imprimir();
		}
		
		for(int i = 0; i < 5; i++) {
			Pessoa pessoa = new Pessoa("Teteste" + i, i+i+i , i+i+""+i+i+i+i);
			pessoa.imprimir();
			pessoas.add(pessoa);
		}
	}
}
	