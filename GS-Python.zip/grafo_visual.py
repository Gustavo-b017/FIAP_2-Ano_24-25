# grafo_estatico.py - Gera uma imagem estática do grafo de rotas com pesos usando apenas matplotlib

import matplotlib.pyplot as plt

def desenhar_grafo():
    fig, ax = plt.subplots(figsize=(10, 7))
    ax.set_xlim(-10, 10)
    ax.set_ylim(-7, 7)
    ax.axis('off')

    # Coordenadas manuais dos pontos
    nodes = {
        "Base Central": (0, 0),
        "Zona Norte": (-5, 5),
        "Vila Verde": (5, 5),
        "Mata Alta": (0, -5)
    }

    # Conexões com pesos
    edges = [
        ("Base Central", "Zona Norte", 10),
        ("Base Central", "Vila Verde", 5),
        ("Zona Norte", "Mata Alta", 7),
        ("Vila Verde", "Mata Alta", 3)
    ]

    # Desenhar nós
    for name, (x, y) in nodes.items():
        ax.add_patch(plt.Circle((x, y), 0.8, color='lightblue', ec='black'))
        ax.text(x, y, name, fontsize=9, ha='center', va='center', weight='bold')

    # Desenhar arestas com pesos
    for origem, destino, peso in edges:
        x1, y1 = nodes[origem]
        x2, y2 = nodes[destino]
        ax.plot([x1, x2], [y1, y2], 'k-', linewidth=1.5)
        mid_x = (x1 + x2) / 2
        mid_y = (y1 + y2) / 2
        ax.text(mid_x, mid_y, str(peso), fontsize=9, color='darkred', weight='bold')

    plt.title("Mapa de Rotas - Visualização Estática", fontsize=12, weight='bold')
    plt.tight_layout()

    # Salvar imagem no diretório raiz
    plt.savefig("grafo_rotas_estatico.png", bbox_inches='tight')
    plt.show()

if __name__ == "__main__":
    desenhar_grafo()
