# lista_status_areas.py - Lista ligada para controle de status das áreas afetadas

class NodoStatus:
    """
    Representa um nodo da lista ligada com o status de uma área.
    """
    def __init__(self, status):
        self.status = status
        self.proximo = None

class ListaStatusAreas:
    """
    Lista ligada para rastrear o histórico de status de uma área (ex: ativo -> contido -> resolvido).
    """
    def __init__(self):
        self.inicio = None

    def adicionar_status(self, status):
        """
        Adiciona um novo status ao final da lista.
        """
        novo = NodoStatus(status)
        if self.inicio is None:
            self.inicio = novo
        else:
            atual = self.inicio
            while atual.proximo:
                atual = atual.proximo
            atual.proximo = novo

    def listar_status(self):
        """
        Retorna todos os status registrados na lista em ordem.
        """
        status_list = []
        atual = self.inicio
        while atual:
            status_list.append(atual.status)
            atual = atual.proximo
        return status_list
