# app.py - Simulação oficial baseada nas exigências do professor

from exemplos_dados import chamadas_emergencia, pesos_vegetacao, grafo_mapa
from fila_chamados import FilaChamados
from heap_prioridade import HeapPrioridade
from historico_acoes import HistoricoAcoes
from lista_status_areas import ListaStatusAreas
from arvore_localizacao import Estado
from dijkstra import dijkstra

def main():
    print("\n=== CENTRAL DE EMERGÊNCIAS - RESPOSTA A QUEIMADAS E RESGATE DE FAUNA ===\n")

    # 1. Estrutura geográfica (ÁRVORE)
    print("REGIÃO MONITORADA")
    estado = Estado("SP")
    estado.adicionar_zona_em_municipio("SP", "Zona Norte")
    estado.adicionar_zona_em_municipio("SP", "Mata Alta")
    estado.adicionar_zona_em_municipio("SP", "Vila Verde")

    estrutura = estado.listar_tudo()
    for municipio, zonas in estrutura.items():
        print(f"- {municipio}: {', '.join(zonas)}")

    # 2. Registro das chamadas de emergência (FILA)
    print("\nCHAMADAS RECEBIDAS (FILA)")
    fila = FilaChamados()
    for chamada in chamadas_emergencia:
        fila.adicionar_chamada(chamada)
        print(f"> ID {chamada['id']} - {chamada['local']} | Severidade: {chamada['severidade']} | Vegetação: {chamada['tipo_vegetacao']}")

    # 3. Priorização das chamadas (HEAP)
    print("\nPRIORIZAÇÃO DAS OCORRÊNCIAS (HEAP)")
    heap = HeapPrioridade(pesos_vegetacao)
    while not fila.esta_vazia():
        heap.inserir_chamada(fila.proxima_chamada())

    for item in heap.listar_heap():
        print(f"> ID {item['id']} - {item['local']}")

    # 4. Atendimento da ocorrência mais urgente
    print("\nATENDIMENTO DA OCORRÊNCIA MAIS URGENTE")
    ocorrencia = heap.extrair_chamada()
    if not ocorrencia:
        print("Nenhuma ocorrência disponível.")
        return

    origem = "Base Central"
    destino = ocorrencia["local"]
    print(f"> Ocorrência ID {ocorrencia['id']} em {destino}")

    # 5. Rota mais curta (GRAFO - DIJKSTRA)
    caminho, distancia = dijkstra(grafo_mapa, origem, destino)
    print(f"> Rota recomendada: {' -> '.join(caminho)}")
    print(f"> Tempo estimado de deslocamento: {distancia} km")

    # 6. Registro das ações (PILHA)
    print("\nHISTÓRICO DE AÇÕES EXECUTADAS")
    acoes = HistoricoAcoes()
    acoes.registrar_acao("Equipe deslocada")
    acoes.registrar_acao("Barreira de contenção aplicada")
    acoes.registrar_acao("Aceiro criado")
    acoes.registrar_acao("Animais resgatados")

    for acao in acoes.listar_acoes():
        print(f"- {acao}")

    # 7. Status da área (LISTA LIGADA)
    print("\nSTATUS DA ÁREA AFETADA")
    status_area = ListaStatusAreas()
    status_area.adicionar_status("ativo")
    status_area.adicionar_status("em contenção")
    status_area.adicionar_status("controlado")

    for status in status_area.listar_status():
        print(f"- {status}")

if __name__ == "__main__":
    main()
