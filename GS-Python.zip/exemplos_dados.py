# exemplos_dados.py - Dados simulados para testes do sistema

# Lista de chamadas de emergência (simula a fila de entrada)
chamadas_emergencia = [
    {"id": 1, "local": "Zona Norte", "severidade": 4, "tipo_vegetacao": "cerrado"},
    {"id": 2, "local": "Mata Alta", "severidade": 5, "tipo_vegetacao": "pantanal"},
    {"id": 3, "local": "Vila Verde", "severidade": 3, "tipo_vegetacao": "mata_atlantica"}
]

# Pesos por tipo de vegetação para o cálculo de prioridade
pesos_vegetacao = {
    "cerrado": 1.2,
    "mata_atlantica": 1.5,
    "pantanal": 2.0
}

# Grafo do mapa representando conexões entre locais e distâncias
grafo_mapa = {
    "Base Central": {"Zona Norte": 10, "Vila Verde": 5},
    "Zona Norte": {"Base Central": 10, "Mata Alta": 7},
    "Vila Verde": {"Base Central": 5, "Mata Alta": 3},
    "Mata Alta": {"Zona Norte": 7, "Vila Verde": 3}
}
