# arvore_localizacao.py - Estrutura de árvore para representar hierarquia geográfica

class Zona:
    def __init__(self, nome):
        self.nome = nome

class Municipio:
    def __init__(self, nome):
        self.nome = nome
        self.zonas = {}  # dicionário de zonas

    def adicionar_zona(self, nome_zona):
        if nome_zona not in self.zonas:
            self.zonas[nome_zona] = Zona(nome_zona)

class Estado:
    def __init__(self, nome):
        self.nome = nome
        self.municipios = {}  # dicionário de municípios

    def adicionar_municipio(self, nome_municipio):
        if nome_municipio not in self.municipios:
            self.municipios[nome_municipio] = Municipio(nome_municipio)

    def adicionar_zona_em_municipio(self, nome_municipio, nome_zona):
        if nome_municipio not in self.municipios:
            self.adicionar_municipio(nome_municipio)
        self.municipios[nome_municipio].adicionar_zona(nome_zona)

    def listar_tudo(self):
        """
        Lista toda a estrutura do estado: municípios e zonas.
        """
        estrutura = {}
        for nome_mun, mun in self.municipios.items():
            estrutura[nome_mun] = list(mun.zonas.keys())
        return estrutura
