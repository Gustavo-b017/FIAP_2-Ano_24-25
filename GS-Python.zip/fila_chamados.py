# fila_chamados.py - Estrutura de Fila para gerenciar chamadas de emergência

from collections import deque

class FilaChamados:
    """
    Fila para armazenar as chamadas de emergência em ordem de chegada.
    Utiliza deque por ser eficiente para operações de inserção e remoção.
    """

    def __init__(self):
        self.fila = deque()

    def adicionar_chamada(self, chamada):
        """
        Adiciona uma nova chamada ao final da fila.
        """
        self.fila.append(chamada)

    def proxima_chamada(self):
        """
        Remove e retorna a próxima chamada da fila (primeiro a entrar).
        """
        if not self.esta_vazia():
            return self.fila.popleft()
        return None

    def esta_vazia(self):
        """
        Verifica se a fila está vazia.
        """
        return len(self.fila) == 0

    def tamanho(self):
        """
        Retorna a quantidade de elementos na fila.
        """
        return len(self.fila)

    def listar_fila(self):
        """
        Retorna uma lista com todas as chamadas na fila.
        """
        return list(self.fila)
