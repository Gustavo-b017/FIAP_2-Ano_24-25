# calcular_prioridade.py - Função para calcular a prioridade de atendimento de uma chamada

def calcular_prioridade(chamada, pesos_vegetacao):
    """
    Calcula a prioridade de uma chamada de emergência com base na severidade do foco
    e no tipo de vegetação, conforme regra definida pelo professor.

    Fórmula:
    prioridade = severidade * peso_vegetacao

    Parâmetros:
    - chamada (dict): Um dicionário contendo 'severidade' e 'tipo_vegetacao'.
    - pesos_vegetacao (dict): Um dicionário com os pesos associados aos tipos de vegetação.

    Retorno:
    - float: Valor da prioridade calculada.
    """

    severidade = chamada.get("severidade", 0)
    tipo = chamada.get("tipo_vegetacao", "").lower()

    # Peso padrão se tipo não for encontrado
    peso = pesos_vegetacao.get(tipo, 1.0)

    return severidade * peso
