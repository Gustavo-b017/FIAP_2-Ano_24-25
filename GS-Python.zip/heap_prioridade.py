# heap_prioridade.py - Estrutura de Heap para organizar chamadas por prioridade

import heapq
from calcular_prioridade import calcular_prioridade

class HeapPrioridade:
    """
    Heap de chamadas com base na prioridade calculada (quanto maior a prioridade, mais urgente).
    Usa heapq (min-heap), por isso os valores são negativos para simular max-heap.
    """

    def __init__(self, pesos_vegetacao):
        self.heap = []
        self.pesos_vegetacao = pesos_vegetacao

    def inserir_chamada(self, chamada):
        """
        Calcula a prioridade da chamada e insere na heap.
        """
        prioridade = calcular_prioridade(chamada, self.pesos_vegetacao)
        heapq.heappush(self.heap, (-prioridade, chamada))  # negativo para max-heap

    def extrair_chamada(self):
        """
        Remove e retorna a chamada de maior prioridade.
        """
        if not self.esta_vazia():
            return heapq.heappop(self.heap)[1]
        return None

    def esta_vazia(self):
        """
        Verifica se a heap está vazia.
        """
        return len(self.heap) == 0

    def listar_heap(self):
        """
        Retorna uma lista com as chamadas organizadas por prioridade (sem alterar a heap).
        """
        return [item[1] for item in sorted(self.heap, reverse=True)]
