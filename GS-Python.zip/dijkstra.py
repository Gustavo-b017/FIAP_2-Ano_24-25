# dijkstra.py - Algoritmo para calcular o menor caminho entre dois pontos em um grafo

import heapq

def dijkstra(grafo, origem, destino):
    """
    Calcula o menor caminho entre dois pontos em um grafo usando o algoritmo de Dijkstra.

    Parâmetros:
    - grafo (dict): Grafo representado como dicionário de adjacências com pesos.
      Exemplo: {"A": {"B": 5, "C": 2}, "B": {"C": 1}, ...}
    - origem (str): Nome do ponto de partida.
    - destino (str): Nome do ponto de chegada.

    Retorno:
    - caminho (list): Lista com os nomes dos pontos na ordem do menor caminho.
    - distancia_total (int/float): Soma dos pesos do menor caminho.
    """

    fila = [(0, origem, [])]  # (distância acumulada, vértice atual, caminho percorrido)
    visitados = set()

    while fila:
        custo, atual, caminho = heapq.heappop(fila)

        if atual in visitados:
            continue
        visitados.add(atual)

        caminho = caminho + [atual]

        if atual == destino:
            return caminho, custo

        for vizinho, peso in grafo.get(atual, {}).items():
            if vizinho not in visitados:
                heapq.heappush(fila, (custo + peso, vizinho, caminho))

    return None, float('inf')  # Caminho não encontrado
