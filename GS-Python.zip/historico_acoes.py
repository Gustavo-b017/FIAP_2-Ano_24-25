# historico_acoes.py - Pilha para registrar ações realizadas pela equipe em cada ocorrência

class HistoricoAcoes:
    """
    Pilha para armazenar as ações realizadas por uma equipe durante o atendimento de uma ocorrência.
    Funciona como LIFO: a última ação realizada é a primeira a ser desfeita, se necessário.
    """

    def __init__(self):
        self.pilha = []

    def registrar_acao(self, acao):
        """
        Adiciona uma nova ação ao topo da pilha.
        """
        self.pilha.append(acao)

    def desfazer_ultima_acao(self):
        """
        Remove e retorna a última ação registrada (topo da pilha).
        """
        if not self.esta_vazia():
            return self.pilha.pop()
        return None

    def listar_acoes(self):
        """
        Retorna todas as ações registradas, da primeira até a última.
        """
        return self.pilha.copy()

    def esta_vazia(self):
        """
        Verifica se a pilha está vazia.
        """
        return len(self.pilha) == 0
